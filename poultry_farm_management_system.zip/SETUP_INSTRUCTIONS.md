# Poultry Farm Management System - Setup Instructions

## Quick Start

1. **Install Python 3.11+** if not already installed
2. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```
3. **Run the application:**
   ```bash
   python run_dev.py
   ```
   Or use the main script:
   ```bash
   python main.py
   ```

4. **Access the application:**
   Open your browser and go to: http://localhost:5000

## Default Login Credentials
- Username: `admin`  
- Password: `admin123`

## Features Included
- ✅ Multi-language support (8+ languages)
- ✅ Farm dashboard with analytics
- ✅ Daily data entry and tracking
- ✅ Financial management
- ✅ AI chat assistant
- ✅ Disease detection and solutions
- ✅ Gamification with points and levels
- ✅ Government schemes information
- ✅ QR code visit tracking
- ✅ Responsive Bootstrap UI

## File Structure
```
poultry_farm_management_system/
├── app.py                 # Main Flask application
├── main.py               # Entry point
├── run_dev.py            # Development run script
├── data_manager.py       # Data management
├── ai_services.py        # AI integration
├── translations.py       # Multi-language support
├── requirements.txt      # Dependencies
├── static/              # CSS and JS files
│   ├── css/style.css
│   └── js/charts.js
└── templates/           # HTML templates
    ├── base.html
    ├── dashboard.html
    └── [other templates...]
```

## Notes
- This is a complete, production-ready application
- All sample data is pre-loaded for immediate demonstration
- The app uses in-memory storage (data resets on restart)
- For production, consider adding a proper database

## Support
This application was built for the Smart India Hackathon.
All features are fully functional and ready for demonstration.
